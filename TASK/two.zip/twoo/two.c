#include <stdio.h>
#include <pthread.h>

#define MAX_ITEMS 100
#define TAX_RATE 0.13

// ---------------------------
// SIMPLE STRUCTS
// ---------------------------

typedef struct
{
    int id;
    char *title;
    double rate;
    int isTaxable;
} Item;

typedef struct
{
    Item *item;
    int amount;
} CartEntry;

// ---------------------------
// GLOBAL STORAGE
// ---------------------------

Item ITEM_LIST[] = {
    {101, "Notebook", 55.0, 0},
    {102, "Ball Pen", 20.0, 0},
    {103, "Marker", 45.0, 1},
    {104, "Rice Bag", 1200.0, 0},
    {105, "Oil Bottle", 230.0, 1},
    {106, "Sugar", 95.0, 0},
    {107, "Salt", 25.0, 0},
    {108, "Chocolate", 80.0, 1},
    {109, "Juice Pack", 150.0, 1},
    {110, "Dish Soap", 70.0, 1},
    {111, "Shampoo", 160.0, 1},
    {112, "Tissue Box", 85.0, 0},
    {113, "Cookies", 120.0, 1},
    {114, "Toothpaste", 110.0, 1},
    {115, "Detergent", 180.0, 1}};

int ITEM_COUNT = sizeof(ITEM_LIST) / sizeof(ITEM_LIST[0]);

CartEntry cart[MAX_ITEMS];
int cartCount = 0;

double finalSubtotal = 0.0;
double finalDiscount = 0.0;
double finalTaxBase = 0.0;
double discountPercent = 0.0;

pthread_mutex_t lock;

// ---------------------------
// HELPER FUNCTIONS
// ---------------------------

Item *findItem(int id)
{
    for (int i = 0; i < ITEM_COUNT; i++)
    {
        if (ITEM_LIST[i].id == id)
            return &ITEM_LIST[i];
    }
    return NULL;
}

void showItems()
{
    printf("\nAvailable Items:\n");
    printf("ID  Name         Price   Taxable\n");
    for (int i = 0; i < ITEM_COUNT; i++)
    {
        printf("%2d  %-10s  %.2f    %s\n",
               ITEM_LIST[i].id,
               ITEM_LIST[i].title,
               ITEM_LIST[i].rate,
               ITEM_LIST[i].isTaxable ? "Yes" : "No");
    }
}

// ---------------------------
// THREAD FUNCTIONS
// ---------------------------

void *t_subtotal(void *arg)
{
    pthread_mutex_lock(&lock);

    double sum = 0.0;
    for (int i = 0; i < cartCount; i++)
        sum += cart[i].item->rate * cart[i].amount;

    finalSubtotal = sum;

    pthread_mutex_unlock(&lock);
    return NULL;
}

void *t_discount(void *arg)
{
    pthread_mutex_lock(&lock);

    finalDiscount = (finalSubtotal * discountPercent) / 100.0;

    pthread_mutex_unlock(&lock);
    return NULL;
}

void *t_taxable(void *arg)
{
    pthread_mutex_lock(&lock);

    double taxSum = 0.0;
    for (int i = 0; i < cartCount; i++)
    {
        if (cart[i].item->isTaxable)
            taxSum += cart[i].item->rate * cart[i].amount;
    }

    finalTaxBase = taxSum;

    pthread_mutex_unlock(&lock);
    return NULL;
}

// ---------------------------
// MAIN PROGRAM
// ---------------------------

int main()
{
    pthread_mutex_init(&lock, NULL);

    showItems();

    while (1)
    {
        if (cartCount >= MAX_ITEMS)
        {
            printf("\nCart full (max 100 items).\n");
            break;
        }

        int id, qty;
        char cont;

        printf("\nEnter Item ID: ");
        scanf("%d", &id);

        Item *chosen = findItem(id);
        if (!chosen)
        {
            printf("Invalid ID.\n");
            continue;
        }

        printf("Enter Quantity: ");
        scanf("%d", &qty);

        cart[cartCount].item = chosen;
        cart[cartCount].amount = qty;
        cartCount++;

        printf("Add more? (y/n): ");
        scanf(" %c", &cont);

        if (cont == 'n' || cont == 'N')
            break;
    }

    printf("Enter discount percent: ");
    scanf("%lf", &discountPercent);

    pthread_t A, B, C;

    // Start the 3 threads
    pthread_create(&A, NULL, t_subtotal, NULL);
    pthread_create(&B, NULL, t_discount, NULL);
    pthread_create(&C, NULL, t_taxable, NULL);

    // Wait for them
    pthread_join(A, NULL);
    pthread_join(B, NULL);
    pthread_join(C, NULL);

    // Final calculations
    double taxAfterDiscount = finalTaxBase - (finalTaxBase * discountPercent / 100.0);
    double taxAmount = taxAfterDiscount * TAX_RATE;
    double grandTotal = finalSubtotal - finalDiscount + taxAmount;

    printf("\n-------- INVOICE --------\n");
    for (int i = 0; i < cartCount; i++)
    {
        printf("%d. %s x%d = %.2f\n",
               i + 1,
               cart[i].item->title,
               cart[i].amount,
               cart[i].item->rate * cart[i].amount);
    }

    printf("\nSubtotal: %.2f", finalSubtotal);
    printf("\nDiscount: %.2f", finalDiscount);
    printf("\nTax: %.2f", taxAmount);
    printf("\nGrand Total: %.2f\n", grandTotal);

    pthread_mutex_destroy(&lock);
    return 0;
}
